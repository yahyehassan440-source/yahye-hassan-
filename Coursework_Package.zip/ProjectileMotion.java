import java.util.Scanner;

public class ProjectileMotion {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter initial velocity (m/s): ");
        double velocity = input.nextDouble();

        System.out.print("Enter launch angle (degrees): ");
        double angle = input.nextDouble();

        double angleRad = Math.toRadians(angle);
        double g = 9.8; // gravity in m/s^2

        // Time of flight
        double timeOfFlight = (2 * velocity * Math.sin(angleRad)) / g;

        // Maximum height
        double maxHeight = Math.pow(velocity * Math.sin(angleRad), 2) / (2 * g);

        // Range
        double range = (Math.pow(velocity, 2) * Math.sin(2 * angleRad)) / g;

        System.out.printf("Time of Flight: %.2f seconds\n", timeOfFlight);
        System.out.printf("Maximum Height: %.2f meters\n", maxHeight);
        System.out.printf("Horizontal Range: %.2f meters\n", range);
    }
}
