import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.sql.*;

public class ExhibitionRegistration extends JFrame {
    private JTextField txtID, txtName, txtDepartment, txtPartner, txtPhone, txtEmail;
    private JLabel lblImage;
    private JButton btnRegister, btnSearch, btnUpdate, btnDelete, btnClear, btnExit, btnUpload;
    private Connection conn;
    private String imagePath = null;

    public ExhibitionRegistration() {
        setTitle("Exhibition Registration System - VUE");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.anchor = GridBagConstraints.WEST;

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; form.add(new JLabel("Registration ID:"), gbc);
        gbc.gridx = 1; txtID = new JTextField(20); form.add(txtID, gbc); y++;

        gbc.gridx = 0; gbc.gridy = y; form.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; txtName = new JTextField(20); form.add(txtName, gbc); y++;

        gbc.gridx = 0; gbc.gridy = y; form.add(new JLabel("Department:"), gbc);
        gbc.gridx = 1; txtDepartment = new JTextField(20); form.add(txtDepartment, gbc); y++;

        gbc.gridx = 0; gbc.gridy = y; form.add(new JLabel("Partner:"), gbc);
        gbc.gridx = 1; txtPartner = new JTextField(20); form.add(txtPartner, gbc); y++;

        gbc.gridx = 0; gbc.gridy = y; form.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1; txtPhone = new JTextField(20); form.add(txtPhone, gbc); y++;

        gbc.gridx = 0; gbc.gridy = y; form.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; txtEmail = new JTextField(20); form.add(txtEmail, gbc); y++;

        gbc.gridx = 0; gbc.gridy = y; form.add(new JLabel("ID Image:"), gbc);
        gbc.gridx = 1; lblImage = new JLabel("No Image Selected"); form.add(lblImage, gbc); y++;

        add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnRegister = new JButton("Register");
        btnSearch = new JButton("Search");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnClear = new JButton("Clear");
        btnExit = new JButton("Exit");
        btnUpload = new JButton("Upload Image");

        buttons.add(btnRegister); buttons.add(btnSearch);
        buttons.add(btnUpdate); buttons.add(btnDelete);
        buttons.add(btnClear); buttons.add(btnExit);
        buttons.add(btnUpload);

        add(buttons, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setSize(700, 450);
        setVisible(true);

        // Connect to Access DB using UCanAccess driver
        try {
            // Ensure ucanaccess jars are in classpath when running
            String dbPath = System.getProperty("user.dir") + File.separator + "VUE_Exhibition.accdb";
            String url = "jdbc:ucanaccess://" + dbPath;
            conn = DriverManager.getConnection(url);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Connection Failed: " + ex.getMessage());
        }

        // Button actions
        btnUpload.addActionListener(e -> uploadImage());
        btnRegister.addActionListener(e -> registerParticipant());
        btnSearch.addActionListener(e -> searchParticipant());
        btnUpdate.addActionListener(e -> updateParticipant());
        btnDelete.addActionListener(e -> deleteParticipant());
        btnClear.addActionListener(e -> clearForm());
        btnExit.addActionListener(e -> { closeConnection(); System.exit(0); });
    }

    private void uploadImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif"));
        int res = chooser.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            imagePath = f.getAbsolutePath();
            lblImage.setText(f.getName());
        }
    }

    private boolean validateInput(boolean requireID) {
        if (requireID && txtID.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Registration ID is required.");
            return false;
        }
        if (txtName.getText().trim().isEmpty() || txtDepartment.getText().trim().isEmpty()
            || txtPhone.getText().trim().isEmpty() || txtEmail.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all required fields.");
            return false;
        }
        // simple phone numeric check
        if (!txtPhone.getText().trim().matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Phone number must contain digits only.");
            return false;
        }
        // simple email check
        if (!txtEmail.getText().trim().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this, "Enter a valid email address.");
            return false;
        }
        return true;
    }

    private void registerParticipant() {
        if (!validateInput(false)) return;
        String sql = "INSERT INTO Participants (RegistrationID, Name, Department, Partner, Phone, Email, ImagePath) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, txtID.getText().trim());
            ps.setString(2, txtName.getText().trim());
            ps.setString(3, txtDepartment.getText().trim());
            ps.setString(4, txtPartner.getText().trim());
            ps.setString(5, txtPhone.getText().trim());
            ps.setString(6, txtEmail.getText().trim());
            ps.setString(7, imagePath);
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Registered (" + rows + ")");
        } catch (SQLIntegrityConstraintViolationException dup) {
            JOptionPane.showMessageDialog(this, "Registration ID already exists.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error inserting: " + ex.getMessage());
        }
    }

    private void searchParticipant() {
        if (!validateInput(true)) return;
        String sql = "SELECT * FROM Participants WHERE RegistrationID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, txtID.getText().trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    txtName.setText(rs.getString("Name"));
                    txtDepartment.setText(rs.getString("Department"));
                    txtPartner.setText(rs.getString("Partner"));
                    txtPhone.setText(rs.getString("Phone"));
                    txtEmail.setText(rs.getString("Email"));
                    imagePath = rs.getString("ImagePath");
                    lblImage.setText(imagePath != null ? new File(imagePath).getName() : "No Image Selected");
                } else {
                    JOptionPane.showMessageDialog(this, "No participant found with that ID.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage());
        }
    }

    private void updateParticipant() {
        if (!validateInput(true)) return;
        String sql = "UPDATE Participants SET Name=?, Department=?, Partner=?, Phone=?, Email=?, ImagePath=? WHERE RegistrationID=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, txtName.getText().trim());
            ps.setString(2, txtDepartment.getText().trim());
            ps.setString(3, txtPartner.getText().trim());
            ps.setString(4, txtPhone.getText().trim());
            ps.setString(5, txtEmail.getText().trim());
            ps.setString(6, imagePath);
            ps.setString(7, txtID.getText().trim());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Updated (" + rows + ")");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Update error: " + ex.getMessage());
        }
    }

    private void deleteParticipant() {
        if (!validateInput(true)) return;
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this participant?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        String sql = "DELETE FROM Participants WHERE RegistrationID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, txtID.getText().trim());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Deleted (" + rows + ")");
            if (rows > 0) clearForm();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Delete error: " + ex.getMessage());
        }
    }

    private void clearForm() {
        txtID.setText(""); txtName.setText(""); txtDepartment.setText(""); txtPartner.setText(""); txtPhone.setText(""); txtEmail.setText(""); lblImage.setText("No Image Selected"); imagePath = null;
    }

    private void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) conn.close();
        } catch (SQLException e) {
            // ignore
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ExhibitionRegistration());
    }
}
