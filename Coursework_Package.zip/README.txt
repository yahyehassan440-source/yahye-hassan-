README - Coursework Package for 2246 EDU - Computer Programming
---------------------------------------------------------------

Files included:
- ProjectileMotion.java
- ExhibitionRegistration.java
- Coursework_Answers.docx  (detailed documentation and screenshots placeholders)
- participants_sample.csv   (sample data to import into Access)
- README.txt (this file)

What you still need to do on your PC:
1. Create the Access database (VUE_Exhibition.accdb)
   - Open MS Access, create a new blank database and save it as VUE_Exhibition.accdb
   - Create a table named 'Participants' with columns:
     * RegistrationID (Text) - Primary Key
     * Name (Text)
     * Department (Text)
     * Partner (Text)
     * Phone (Text)
     * Email (Text)
     * ImagePath (Text)

   - Alternatively, import 'participants_sample.csv' into Access to create sample entries.
     The CSV file has 5 sample participants.

2. Put the Access DB file (VUE_Exhibition.accdb) in the same folder as the Java .class files
   or the project working directory. The Java application expects the DB at runtime:
     VUE_Exhibition.accdb
   (When running from IDE, ensure working directory contains the accdb or update the path in code.)

3. Required libraries (UCanAccess):
   - Download UCanAccess (ucanaccess-x.x.x.jar) and its dependencies (jackcess, commons-lang, commons-logging, hsqldb)
   - When compiling/running the Java app, include all JARs in the classpath. Example (command line):
     javac -cp ".;lib/*" ExhibitionRegistration.java
     java -cp ".;lib/*" ExhibitionRegistration
   - If using an IDE (Eclipse/IntelliJ/NetBeans), add the jars to the project libraries.

4. Sample SQL to create Participants table (if you prefer SQL):
   CREATE TABLE Participants (
     RegistrationID TEXT PRIMARY KEY,
     Name TEXT,
     Department TEXT,
     Partner TEXT,
     Phone TEXT,
     Email TEXT,
     ImagePath TEXT
   );

5. Sample INSERT statements for 5 participants:
   INSERT INTO Participants (RegistrationID, Name, Department, Partner, Phone, Email, ImagePath) VALUES ('REG001','Aisha Mohamed','Computer Science','Hassan Omar','256701234567','aisha@example.com','C:\\images\\id1.jpg');
   INSERT INTO Participants (RegistrationID, Name, Department, Partner, Phone, Email, ImagePath) VALUES ('REG002','John Okello','Engineering','Mary Kato','256702345678','john@example.com','C:\\images\\id2.jpg');
   INSERT INTO Participants (RegistrationID, Name, Department, Partner, Phone, Email, ImagePath) VALUES ('REG003','Grace Nanyonga','Business','Paul Lumu','256703456789','grace@example.com','C:\\images\\id3.jpg');
   INSERT INTO Participants (RegistrationID, Name, Department, Partner, Phone, Email, ImagePath) VALUES ('REG004','David Mwanga','Art and Design','Rita Ssemanda','256704567890','david@example.com','C:\\images\\id4.jpg');
   INSERT INTO Participants (RegistrationID, Name, Department, Partner, Phone, Email, ImagePath) VALUES ('REG005','Fatima Ali','Education','Noor Hussein','256705678901','fatima@example.com','C:\\images\\id5.jpg');

6. Screenshots / PDF:
   - Run the ExhibitionRegistration app on your PC and take screenshots of the GUI, register/search/update/delete outputs.
   - Paste the screenshots into Coursework_Answers.docx (already contains placeholders) or save as a separate PDF and include in GitHub repo.

7. Submitting to V-Class / GitHub:
   - Create a GitHub repository and upload all files including VUE_Exhibition.accdb (the actual Access file).
   - Provide the GitHub link in V-Class for submission.
   - Also upload the Coursework_Answers.docx (with screenshots) as required by the coursework spec.

Notes & Support:
- I cannot create a native .accdb file from this environment. Please follow step (1) to create the DB on your PC.
- If you want, I can generate SQL and a CSV (included) to make importing into Access easier.
- Tell me once you've created the accdb and run the app; I can help polish screenshots, README, or produce a PDF version for submission.
